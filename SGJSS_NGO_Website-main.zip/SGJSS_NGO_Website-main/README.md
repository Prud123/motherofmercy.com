# SGJSS_NGO_Website

_**Created By [Omkar Jadhav](https://github.com/Omkaroj1242), [Sheenam Goel](https://github.com/SheenamGoel),  and [Mahesh Babar](https://github.com/maheshdbabar9340)**_

_**Take a view at => https://sgjss.netlify.app/ OR [SGJSS_NGO_Website](https://maheshdbabar9340.github.io/SGJSS_NGO_Website/)**_

**smtp.js for sending E-mails ==> https://kaustubh72.medium.com/send-e-mails-with-smtp-js-a8e07e1d0b6b**
